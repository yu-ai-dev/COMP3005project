const express = require('express')
const ejs = require('ejs');
const bodyParser = require('body-parser')
const app = express()
const db = require('./queries')
const port = 3000



app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)

//set the view engine to ejs
app.set('view engine', 'ejs');

app.get('/wholebooks', function(req, res) {//Bookstore
    res.render('pages/book');
});
app.get('/register', function(req, res) {//register
    res.render('pages/register');
});
app.get('/', function(req, res) {//login
    res.render('pages/login');
});

app.get('/books', db.getBooks);
app.get('/books/:id', db.getBookById);
app.post('/user', db.createUser);
app.post('/searchAuthor', db.searchAuthor);
app.post('/searchTitle', db.searchTitle);
app.post('/login', db.login);

app.listen(port, () => {
  console.log(`App running on port ${port}.`)
})
