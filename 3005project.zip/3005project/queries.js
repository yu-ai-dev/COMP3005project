const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'password',
  port: 5432,
})


const getBooks = (request, response) => {
  pool.query('SELECT * from book', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const getBookById = (request, response) => {
  const id = parseInt(request.params.id);
  pool.query('SELECT * FROM book WHERE amazon_index = $1', [id], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}


const createUser = (request, response) => {
  const {password, firstname, lastname } = request.body
  //console.log(request.body);
  pool.query('INSERT INTO users (password, firstname, lastname) VALUES ($1, $2, $3)', [password, firstname, lastname], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`users added with amazon_index: ${results.insertId}`)
  })
}


const searchAuthor = (request, response) => {
  const {searchAuthor} = request.body;

  pool.query('SELECT * FROM book WHERE author like $1', [searchAuthor], (error, results) => {
    if (error) {
      throw error
    }
    // console.log(results.rows);
    response.status(200).json(results.rows);
  })
}

const searchTitle = (request, response) => {
  const {searchTitle} = request.body;

  pool.query('SELECT * FROM book WHERE title like $1', [searchTitle], (error, results) => {
    if (error) {
      throw error
    }
     //console.log(results.rows);
    response.status(200).json(results.rows);
  })
}

const login = (request, response) => {
  const {firstname, lastname, password} = request.body;

  pool.query('SELECT * FROM users WHERE firstname like $1 and lastname like $2 and password = $3', [firstname,lastname, password], (error, results) => {
    if (error) {
      throw error
    }
     console.log(results.rows);
    response.status(200).json(results.rows);
  })
}



module.exports = {
  getBooks,
  getBookById,
  createUser,
  searchAuthor,
  searchTitle,
  login,
  // updateUser,
  // deleteUser,
}
